type k = int

let vote neighbor_labels = ()
let predict x = ()
