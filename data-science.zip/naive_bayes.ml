let fit x y = ()
let calc_likelihood mean var x = ()
let calc_prior c = ()
let classify sample = ()
let predict x = ()

let x = Matrix.eye 5 