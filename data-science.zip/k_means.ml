type k = int
type max_iterations = int

let init_random_centroids x = ()
let closest_centroid sample centroids = ()
let create_clusters = ()
let calc_centroids = ()
let get_cluster_labels = ()
let predict x = ()