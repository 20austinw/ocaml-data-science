let calc_variance_reduc = ()
let mean_of_y y = ()
let fit x y = ()
