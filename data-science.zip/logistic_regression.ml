(* Will use gradient descent with this. 
Check link: https://rickwierenga.com/blog/ml-fundamentals/logistic-regression.html*)
let sigmoid = ()

type t = { num_iterations : int; learning_rate : float }

let fit x y = ()

let predict x = ()
