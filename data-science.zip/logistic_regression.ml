(* Will use gradient descent with this. *)
let sigmoid = ()

type t = {
  num_iterations : int;
  learning_rate : float;
}

let fit x y = ()
let predict x = ()
