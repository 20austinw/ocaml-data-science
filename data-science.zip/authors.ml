let hours_worked = 47
