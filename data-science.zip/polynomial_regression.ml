type t = {
  num_iterations : int;
  learning_rate : float;
  degree : int;
}

let fit x y = ()
let predict x = () 