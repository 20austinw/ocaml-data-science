let calc_information_gain = ()
let majority_vote = ()
let fit x y = ()